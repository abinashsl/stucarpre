from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

# Replace these with your actual RDS details
rds_host = 'database-1.cjscgyo2o21j.ap-south-1.rds.amazonaws.com'
db_name = 'stucarpre'
user_name = 'admin'
password = '1Abinash'
port = 3306  # or your custom port if different

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/store_data', methods=['POST'])
def store_data():
    # Get data from the form
    username = request.form['username']
    password = request.form['password']

    try:
        # Establish the connection to RDS
        connection = mysql.connector.connect(
            host=rds_host,
            user=user_name,
            password=password,
            database=db_name,
            port=port
        )

        # Create a cursor object to execute SQL queries
        cursor = connection.cursor()

        # Example query to insert data into a table (replace 'your_table' with your actual table name)
        query = "INSERT INTO your_table (username, password) VALUES (%s, %s)"
        data = (username, password)

        # Execute the query
        cursor.execute(query, data)

        # Commit the changes
        connection.commit()

        return "Data stored successfully."

    except mysql.connector.Error as err:
        return f"Error: {err}"

    finally:
        # Close the cursor and connection
        if 'connection' in locals() and connection.is_connected():
            cursor.close()
            connection.close()

if __name__ == '__main__':
    app.run(debug=True)
